#Maria Girgis
#9/13/22
#This program asks the user for their name then greets them 20 times

def main():
    name=input("what is your name?")

    for i in range(20):
        print("Hello",name)
    
    number=eval(input("how many times do you want me to say happy birthday?"))

    for i in range(number):
        print(i+1,"Happy Birthday!",name)

main()
