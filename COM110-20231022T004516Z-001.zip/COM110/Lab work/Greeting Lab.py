#Maria Girgis
#September 13,2022
#This program prompts the user to enter their name, and then greets them

n=input("enter your name here")

print("Hello",n,"hope you are doing well!")
