#Maria Girgis
#Lab 4
#9/27/22

#inputFile = open("ObamaSpeech2012.txt", "r", encoding = "utf-8")
#inputFile1 = open("RomneySpeech2012.txt", "r", encoding = "utf-8")

def wordCounter():
    inputFileOriginal= open("ObamaSpeech2012.txt", "r", encoding = "utf-8")
    inputFileOriginal1 = open("RomneySpeech2012.txt", "r", encoding = "utf-8")
    
    inputFile= inputFileOriginal.read()
    inputFile1= inputFileOriginal1.read()

    inputFileSplit= inputFile.split()
    inputFileSplit1= inputFile1.split()

    inputFileLength=len(inputFileSplit)
    inputFileLength1=len(inputFileSplit1)

    print(inputFileLength)
    print(inputFileLength1)

    if inputFileLength> inputFileLength1:
        print("Obama Speech is longer than Romney Speech")
    else:
        print("Romney Speech is longer than Obama Speech")

    userWord=input("choose a word to count in the speech")
    
    econCount=inputFile.lower().count(userWord)
    econCount1=inputFile1.lower().count(userWord)

    if econCount> econCount1:
        print("Obama Speech has more mention of word")
    else:
        print("Romney speeech has more mention of word")

    print(econCount)
    print(econCount1)
    
    
    #numberOfWords=0
    #numberOfWords1=0

    
#def findEcon():
    #inputFileOriginal=open("ObamaSpeech2012.txt"
        
    
 
    #inputFile=inputFile.split()
    #numberOfWords+=len(inputFile)
    #print(numberOfWords)
    



    inputFileOriginal.close()
    inputFileOriginal1.close()
    
wordCounter()
