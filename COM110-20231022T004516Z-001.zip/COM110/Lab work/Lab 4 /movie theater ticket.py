#Maria Girgis
#Lab 4 movie theater ticket




    

def ticketPrice():
    movieTime=input("if you would like a morning screening type (A)\n if you would lke a evening screening type (B)")
    ticketPrice=20
    matinee= ticketPrice/2
    patronAge=eval(input("how old are you?"))
    
    if movieTime == "A":
        ticketPrice=matinee
        
    if patronAge<3:
        print("your ticket is",0,"$")
    elif patronAge<11:
        print("your ticket is", ticketPrice/2,"$")
    elif patronAge>11 and patronAge<60:
        print("your ticket is", ticketPrice,"$")
    elif patronAge>60:
        print("your ticket is", ticketPrice*0.75, "$")
        
    
def movieList():
    print("up")
    print("jurassic park")
    print("the ring")

def main():
    priceOrMovie=input("would you like to \n(A)List Movies \n(B)Calculate ticket Price")
    
    if priceOrMovie=="A":
        movieList()
    else:       
        ticketPrice()
main()

        
    
