#maria Girgis
#Lab 2
#9/13/22
#Go to the power of 2

def main():
    for i in range(1,21):
        print("2^",i,2**i)

main()
