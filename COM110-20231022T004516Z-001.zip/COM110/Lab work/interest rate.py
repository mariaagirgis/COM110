#Maria Girgis
#Lab 2 Bonuses


principal=0
rate=eval(input("what interest rate would you like to compound your money by?"))

