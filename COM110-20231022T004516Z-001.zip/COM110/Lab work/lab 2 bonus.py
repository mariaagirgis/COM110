#Maria Girgis
#Lab 2 Bonus Part B
#9/13/22

#value=int(input("give a value to get 25 multiples of"))

#for i in range(25):
    #print(value*i)

#def multiples_of_n():

    #value=int(input("give a value to get multiples of"))
    #multiples=int(input("state how many multiples you want"))

    #for i in range(multiples):
        #print(value*i)

#number=0

#while number>0:
    #print(number)
    #number=number-1



#def count_down():
    #value=int(input("What number would you like to count down from?"))
    #number=value
    #while number>0:
        #print(number)
        #number=number-1

#count_down()

#n=0

#while n<1000:
    #n+=1
    #print(n)

value=int(input("enter a number to compound to"))
sum=0
for i in range(value):
    sum=i+1+sum
print(sum)
   
