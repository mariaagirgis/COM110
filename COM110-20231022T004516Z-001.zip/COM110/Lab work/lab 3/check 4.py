#Lab 3 

inputfile = open("lab3poem.txt", "r", encoding="utf-8")

textReader=inputfile.read()

print(textReader)

inputfile.close()
