#lab 3 moreeeee

inputfile = open("lab3poem.txt", "r", encoding="utf-8")



for i in inputfile:
    print(i)
    
inputfile.close()
