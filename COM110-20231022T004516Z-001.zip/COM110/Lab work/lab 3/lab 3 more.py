#lab 3 more

inputfile = open("lab3poem.txt", "r", encoding="utf-8")

lineReader= inputfile.readline()\

print(lineReader)

linesReader= inputfile.readlines()\

print(linesReader)

inputfile.close()
