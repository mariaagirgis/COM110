#lab 3 so much more

outputfile = open("lab3output.txt","w")

outputfile.write("Hello World")

for i in range(3):
    outputfile.write("Maria Girgis\n")
    

outputfile.close()
