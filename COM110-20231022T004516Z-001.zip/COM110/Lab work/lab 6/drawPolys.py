from graphics import *
from time import *

###drawButton() function we made in class 
def drawButton(win, pt1, pt2, label):
    button = Rectangle(pt1, pt2)
    button.setFill("blue3")
    button.draw(win)

    #find the x and y coords of the middle of the button
    centerX = (pt1.getX() + pt2.getX())/2.0 
    centerY = (pt1.getY() + pt2.getY())/2.0

    #use these coords for the position of the label
    btnLabel = Text(Point(centerX,centerY), label)
    btnLabel.setFill("white")
    btnLabel.draw(win)

    return button

###isClicked() function we made in class 
def isClicked(button, point):

    #find x and y coordinate of the point
    x = point.getX()
    y = point.getY()

    #get two corner points of the rectangle object
    pt1 = button.getP1()
    pt2 = button.getP2()

    #calc min/max for the range of x and y
    minX = min(pt1.getX(), pt2.getX())
    maxX = max(pt1.getX(), pt2.getX())
    minY = min(pt1.getY(), pt2.getY())
    maxY = max(pt1.getY(), pt2.getY())

    #range test
    if ( minX <= x <= maxX and minY <= y <= maxY):
        return True
    else:
        return False


def main():

    #create window with size of 600 x 600
    win = GraphWin("Interactive Drawing", 600, 600, autoflush=False)
    
    
    myColor = Entry(Point(300, 120), 10)
    myColor.draw(win)
    myColor.setText("55, 55, 55")
    colorLabel = Text(Point(300, 90), "Enter Color (r, g, b)")
    colorLabel.draw(win)

    
    #a text object for onscreen instruction and message
    msgLabel = Text(Point(300, 35), 'Click mouse to add a point (6 points)')
    msgLabel.setSize(15)
    msgLabel.draw(win)

    btn = drawButton(win, Point(50,50), Point(100,100), "add color")

    draw = drawButton(win, Point(50, 125), Point(100, 175), "draw")

    quitBtn = drawButton(win, Point(50, 200), Point(100, 250), "quit")
    
    
    #point list to store mouse click points
    pointList = []

    # takes 5 mouse click and append it to pointList
    while True:
        target = win.getMouse()
        pointList.append(target)
        #for reference draw a point on window
        target.draw(win)

        if isClicked(draw, target) is True:
            
            myPoly = Polygon(pointList[:-1])
            myPoly.draw(win)
            pointList = []

        if isClicked(btn, target) == True:

            newColor = myColor.getText().split(',')

            myPoly.setFill(color_rgb(int(newColor[0]), int(newColor[1]), int(newColor[2])))
            pointList = []

        if isClicked(quitBtn, target) == True:

            break

    #some message to a user
    msgLabel.setText('Good job. Very interesting. Click anywhere to close.')

    #wait for click to close window
    win.getMouse()
    
    # close window
    win.close()  

main()
