#COM110 Lab6 sample program

from graphics import *
from random import randrange

###you may copy & paste isClicked() function we made in class here
#tests if the point is within the rectangle object or not
def isClicked(button, point):

    #find x and y coordinate of the point
    x = point.getX()
    y = point.getY()

    #get two corner points of the rectangle object
    pt1 = button.getP1()
    pt2 = button.getP2()

    #test if (x,y) fits within the rectangle area
    if ( pt1.getX() <= x <= pt2.getX() and pt1.getY() <= y <= pt2.getY()):
        return True
    else:
        return False


def main():

    #create window    
    win = GraphWin("Fun #5", 600, 600)
    
    #create & draw a rectangle
    square = Rectangle(Point(200,200),Point(400,400))
    square.draw(win)
    pt3= win.getMouse()

    ###your code to check user's mouse click on the rectangle
    if isClicked(square,pt3)== True:
        print("clicled")
        r=randrange(0,256)
        g=randrange(0,256)
        b=randrange(0,256)
        square.setFill(color_rgb(r,g,b))
    ###recall isClicked function we implemented in class
    ###recall indefinite while loop and randrange function
    
    #wait for mouse click and then close window
    win.getMouse()
    win.close()

main()
