
list(range(10,0,-1))
     
