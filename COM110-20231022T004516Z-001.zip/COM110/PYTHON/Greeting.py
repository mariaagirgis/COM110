print("Hello, world!")
print(2+3)
print("2+3=", 2+3)

def hello():
    print("Hello")
    print("Computers are fun!")
hello()

def greet(person):
    print("Hello", person)
    print("How are you?")

greet("John")

greet("Emily")
