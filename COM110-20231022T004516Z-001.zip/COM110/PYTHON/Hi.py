#Practice program in class (Lecture 2)
#Writing eager greeter

def main():
    for i in range(1,11):
        print(i,"Hi")
     
main()
