print("Hello, world!")
print("Hello", "world!")
print(3)
print(3.0)
print(2 + 3)
print(2.0 + 3.0)
print("2" + "3")
print("2+3=",2+3)
print(2 * 3)
print(2 ** 3)
print(7 / 3)
print(7 // 3)

n = eval(input("How many numbers should I print? "))

def main():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(n):
        x = 2.0 * x * (1 - x)
        print(x)
main()



n = eval(input("How many numbers should I print? "))

def main2():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(n):
        x = 3.9*x*(1-x)
        print(x)
main()

n = eval(input("How many numbers should I print? "))

def main3():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(n):
        x = 3.9*(x-x*x)
        print(x)


n = eval(input("How many numbers should I print? "))

def main4():
    print("This program illustrates a chaotic function")
    x = eval(input("Enter a number between 0 and 1: "))
    for i in range(n):
        x = 3.9*x-3.9*x*x
        print(x)



