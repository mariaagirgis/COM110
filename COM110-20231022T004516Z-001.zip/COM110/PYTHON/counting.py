print(3+4)
print(3,4,3+4)
print()
print(3,4,end=" ")
print(3+4)
print("The answer is", 3+4)

