s1="spam"
s2="ni!"

"The Knights who say,"+s2
str(help)




