

def happyBday():
    name=input("whos birthday is it?")
    verse1=("Happy birthday to you")
    print(verse1)
    
    print("happy birthday to", name)
    print(verse1)
    
happyBday()

