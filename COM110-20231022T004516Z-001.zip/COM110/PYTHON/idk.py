
ord('M')
print(ord)
