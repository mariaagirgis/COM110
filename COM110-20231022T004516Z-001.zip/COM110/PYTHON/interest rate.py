#Maria Girgis
#interest rate program
#10/12/22

def futureValue(balance,rate):
    newBal=(1+rate)*balance
    #print("new balance")
    return newBal

def main():
    bal=eval(input("current bal?"))
    rate=eval(input("interest rate?"))
    newBal=futureValue(bal,rate)
    print("future balance is",newBal)


main()

