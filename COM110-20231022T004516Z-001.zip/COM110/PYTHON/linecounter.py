def lineCounter():
    inFile=open('test.txt.','r',encoding='utf-8')

    allLines=inFile.readlines()
    #reads all lines from the file 
    print(allLines)

    numLines=len(allLines)
    print("test.txt fil has total", numLines, "lines.")

    inFile.close()
    
lineCounter()
    
