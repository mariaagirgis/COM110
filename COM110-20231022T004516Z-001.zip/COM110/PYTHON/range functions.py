#Maria Girgis
#Pizza Function

import math



#8/7
#11.50/14

#price divided by area (square inches of pizza)
#find area by pir^2

#areaSmall=50.26548245743669
#areaLarge=153.93804002589985

#def findPrice():
    #inchesSmall=8
    #inchesLarge=14
    #inchesSmall=math.pi*inchesSmall/2**2
    #print(inchesSmall)


def calcArea(diameter,price):
    smallPizza=(math.pi)*(diameter/2)**2
    largePizza=(math.pi)*(diameter/2)**2

    smallPrice=smallPizza/price
    largePrice=largePizza/price
    print(smallPrice)
    print(largePrice)


calcArea(8,7)
calcArea(14,11.50)

