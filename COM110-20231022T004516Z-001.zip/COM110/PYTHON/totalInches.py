#Maria Girgis
#Warmpup 2


#using the simultaneous assignment method, I assigned the variables "feet" and
#"inches" to my function
#This next line is asking the user to input their height in feet and inches
#seperated by a comma 
feet,inches=eval(input("enter your height in feet and inches"))
#I assigned the variable "totalInches" as the answer I need, and on the other
#side of the expression is the conversion for feet to inches
totalInches=feet*12+inches
#This line of code prints out the output or answer to the user 
print("your total height in inches is", totalInches)

#I did not have lot of trouble writing this code because I was using this method
#for my programming assignment
