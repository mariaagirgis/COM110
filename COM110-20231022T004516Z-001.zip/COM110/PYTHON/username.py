#Maria Girgis
#UserID


wholeName=input("Please enter your whole name seperated by spaces-->")

names=wholeName.split()
for names in wholeName:
firstName=names[0]

lastName=names[1]


uid=firstName[0]+lastName

uid=uid.lower()

print("your username is",uid)

email=firstName[0]+lastName

email=email.lower()

print("your email is",email+"@conncoll.edu")

