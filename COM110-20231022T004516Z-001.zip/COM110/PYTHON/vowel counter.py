def vowelCounter():
    inFile=open('test.txt','r',encoding='utf8')
    numVowel=0

    
print('test.txt has', numVowel,'vowels')

    
