#COM110 Graphis
#drawing a point

from graphics import *
	
def main():
    
    myWin = GraphWin('Fun!', 400,400)
    myPt = Point(100, 100)
    myPt.draw(myWin)

    #challenge 1: draw 10 points on mouse click point
   
    for i in range(10):
        pt=myWin.getmouse()
        pt.draw(myWin)


    #challenge 2: draw a line from (100,200) to (300,200)

    
main()
