#input names from classlist.txt
#print out first names only, in alphabetical order

def getLastName(element):
    names=element.split()
    return name[1]

getLastName(key)


def sortClasslist():

    inFile = open("classlist.txt","r", encoding='utf-8')
    names = []

    #real each line from file
    for line in inFile:
        name = line.split() 
        ###your code here to add first name to the list
        firstnames.append(name[0])
        
        names.append(line)
        
   # print(firstnames)
        

    #sort firstnames
    firstnames.sort()
    #print firstnames
    print(firstnames)

    #close file
    inFile.close()



sortClasslist()
