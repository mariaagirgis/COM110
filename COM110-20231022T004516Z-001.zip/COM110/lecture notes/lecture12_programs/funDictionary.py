#dictionary exercise program
#fun interactive dictionary


#main function
def main():

    #create a dictionary
    myVoca = {}

    #print descrption of the program
    print('\nThis is your own interactive dictionary program. Enjoy!\n')

    #take a user input: a word to search
    word = input('Enter a word to search (or exit to quit program): ')

    #create indefinite loop that continues until user enters 'exit' command
    while word != 'exit':

        #test if the word is in our dictionary or not
        #if yes, print its definition



        #else, ask for definition for the word and add it to the dictionary


            
        #take the next input
        word = input('Enter a word to search (or exit to quit program): ')

    #print bye~
    print('\nGood-bye~')
    
main()
