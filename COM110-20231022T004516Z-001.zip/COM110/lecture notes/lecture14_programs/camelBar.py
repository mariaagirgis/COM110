#imageTest.py
#practice working with Zelle Image objects.

from graphics import *

def main():
    win = GraphWin("the Zelle graphics Image class", 800, 400)
    
    imgObj = Image(Point(400,200), "camelsLogo.png")
    imgObj.draw(win)

    #print out some info about our Image object
    imgCenterPt = imgObj.getAnchor()
    print("Image is centered at: (", imgCenterPt.getX(), ",", imgCenterPt.getY(), ")")
    print("Width of image is: ", imgObj.getWidth())
    print("Height of image is:", imgObj.getHeight())
    print("Pixel (0, 0) has rgb values:", imgObj.getPixel(0,0))
    print("Pixel (143, 130) has rgb values:", imgObj.getPixel(143,130))

    #alter the center column of pixels so that they are red
    #you can use setPixel(x, y, colorvalue) method in Image object
    #to change color of pixel. For colorvalue use color_rgb(r,g,b) function

       
    #save changed image to filename, camelsBar.png
    #you can use save(filename) method in Image object
    #use png image format. i.e. filename as "scamelBar.png"
    w=imgObj.getWidth()
    h=imgObj.getHeight()
    #make everything that is 255,255,255 into 255,0,0 (yellow)
    for x in range(w):
        for y in range(h):
            [r,g,b]=imgObj.getPixel(x,y)
            if r==255 and g==255 and b==255:
                imgObj.setPixel(x,y,color_rgb(255,255,0))
    for x in range(w):
        for y in range(h):
            [r,g,b]=imgObj.getPixel(x,y)
            if 
    
##    for x in range(w):
##        for y in range(h):
##            [r,g,b]=imgObj.getPixel(x,y)
##            if r==0 and g==74 and b==141:
##                imgObj.setPixel(x,y,color_rgb(134,23,43))
##    for x in range(0,w,int(w/10)):
##        for y in range(h):
##            imgObj.setPixel(x,y,color_rgb(255,0,0))
##            
##    for x in range(imgObj.getWidth()):
##            for y in range(imgObj.getHeight()):
##                    imgObj.getPixel(imgObj.getWidth()/2,y,color_rgb(255,0,0))
##                    imgObj.getPixel(x,y, 'red')

    imgObj.save("camelsLogoBar.png")
    
    win.getMouse()
    win.close()
    
main()
