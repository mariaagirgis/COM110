 #COM110: lineCounter.py
#This program count the total number of lines in the file

def lineCounter():
    #open file
    inFile = open('test.txt', 'r', encoding='utf-8')
    
    #read all lines from the file
    ###your code here
    #allContents=inFile.read()
    #inFile.seek(0)
    #print(allContents)


    #print result (i.e. test.txt has xxx lines)
    ###your code here
    aLine=inFile.readline()
    inFile.seek(0)
    print(aLine)

    
    #close file
    inFile.close()

lineCounter()
