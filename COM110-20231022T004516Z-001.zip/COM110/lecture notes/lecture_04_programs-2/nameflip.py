#This module is called nameflip.py
#This program will print out a name one letter at a time.

def main():

    #take user input, name
    name = input("Enter your name in quotes: ")

    #write a for loop to print all characters in the name
    #(one letter per line)
    ###your code here


main()
