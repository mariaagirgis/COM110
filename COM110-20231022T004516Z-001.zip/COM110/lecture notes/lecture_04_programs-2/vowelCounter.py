#Maria Girgis
#9/27/22
#Warmup 05 
#This program count the number of vowel occurrence in the file and compares the occurences of i, e, and o in the test.txt file. 

def vowelCounter():
    #opens file 
    inFile = open('test.txt', 'r', encoding='utf-8')
    #reads contents
    contents = inFile.read()
    #initializing variable 
    numVowel = 0
    #setting all str data to lowercase 
    contents=contents.lower()
    #counting all vowels in .txt file
    for vowel in ['e','i','o']:
        num=contents.count(vowel)
        numVowel=numVowel+num
    print('test.txt has', numVowel, 'i,e,o vowel occurence')

    #comparing the occurences of i, e, o using a if elif else statement inside
    #a for loop 
    for vowel in ['i','e','o']:
        numIEO=contents.count(vowel)
        if 'i'>'e' and 'i'>'o':
            print("the vowel i occured the most")
        elif 'e'>'i' and 'e'>'o':
            print("the vowel o occured the most")
        else:
            print("the vowel e occured the most")
      
    #Print the most occuring vowel out of i e and o     
    print('test.txt has', numVowel, 'vowel occurence')

    #At first I had a much more lenghty approach to this program. I was going to
    #manually count the occurences of i e and o seperately using the count function
    #but then I realized I could do it altogether using a for loop like demonstrated in class
    #I wasn't sure if it was going to work, but I put a if else statement inside
    #my for loop, and it worked as expected! I manually counted the occurences of i, e and o in
    #the test.txt file to make sure my program was working as expected. 
    
    inFile.close()

vowelCounter()

