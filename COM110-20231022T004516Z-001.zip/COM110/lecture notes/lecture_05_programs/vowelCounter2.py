#COM110: vowelCounter.py
#This program count the number of vowel occurrence in the file

def vowelCounter():

    #open file
    inFile = open('test.txt', 'r')

    #read in all contents of the file
    contents = inFile.read()

    #variable to store total number of vowels
    numVowel = 0

    #count total number of occurrence of vowel o or O.
    #use if conditional instead of str.count function
    ###your code here



            
    #print result
    print('test.txt has', numVowel, 'vowel occurence')
    
    #close file
    inFile.close()

vowelCounter()
