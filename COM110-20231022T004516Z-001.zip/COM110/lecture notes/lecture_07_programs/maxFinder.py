#COM110: maxFinder.py
#find max number among three values

def main():
    
    #numbers
    numA = 10
    numB = 50
    numC = 1

    #or, you can ask a user to enter three numbers
    #numA, numB, numC = eval(input("Please enter three numbers separated by commas: "))
    
    #which is max?
    ### your code here

    

main()
