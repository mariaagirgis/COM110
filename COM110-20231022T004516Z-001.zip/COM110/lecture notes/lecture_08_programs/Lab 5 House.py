#Maria Girgis
#Lab 5
#10/4/22

from graphics import*

def main():
    myHouse=GraphWin("myHouse!",600,600)
    mySky=Polygon(Point(0,0), Point(600,0), Point(600,500), Point(0,500))
    mySky.draw(myHouse)
    myLine1=Line(Point(225,220), Point(225,350))
    myLine1.draw(myHouse)
    mySky.setFill('lightskyblue')
    myRoof=Polygon(Point(150,150), Point(300,150), Point(350,200), Point(100,200))
    myRoof.draw(myHouse)
    mySun=Circle(Point(550,100),40)
    mySun.draw(myHouse)
    myGrass=Polygon(Point(0,500), Point(600,500), Point(600,600), Point(0,600))
    myGrass.draw(myHouse)
    myBase=Polygon(Point(150,200), Point(300,200), Point(300,500), Point(150,500))
    myBase.draw(myHouse)
    myGarage=Polygon(Point(300,220), Point(500,220), Point(500,500), Point(300,500))
    myGarage.draw(myHouse)
    myWindow=Polygon(Point(200,220), Point(250,220), Point(250,350),Point(200,350))
    myWindow.draw(myHouse)
    myDoor=Polygon(Point(175,400), Point(275,400), Point(275,500), Point(175,500))
    myDoor.draw(myHouse)
    myPath=Polygon(Point(175,500), Point(275,500), Point(275,600), Point(175,600))
    myPath.draw(myHouse)

    myPath.setFill('lightsteelblue3')

    myRoof.setFill('brown4')
    myDoor.setFill('brown4')
    myBase.setFill('lightcyan1')
    myGarage.setFill('lightcyan1')
    myWindow.setFill('lavenderblush3')
    myGrass.setFill('limegreen')
    mySun.setFill('orange1')

    myText=Text(Point(150,100), "Click on lawn yard to plant grass 10 times")
    myText.draw(myHouse)
    myHouse.getMouse()
    myText.undraw()


        

    for i in range(8):
        target=myHouse.getMouse()
        drawGrass(myHouse,target)
        #target.draw(myHouse)
        #print(target)
        
    for i in range(120):
        time.sleep(.01)
        mySun.move(0,10)
    mySky.setFill('black')

    mySun.setFill('grey')
    for i in range(120):
        time.sleep(.01)
        mySun.move(0,-10)
        
    for i in range(30):
        myStar=Circle(Point(randrange(1,600), Point(randrange(1,600)),3))
        myStar.draw(myHouse)

    myStar.setFill('yellow')






    myHouse.getMouse()




    myHouse.close()


def drawGrass(myHouse,target):
    x = target.getX()
    y = target.getY()
    myGrass=Polygon(Point(x,y),Point(x,y-59),Point(x+5,y-24),Point(x+10,y-80), Point(x+10,y-87),Point(x+20,y-37))
    myGrass.setFill('forestgreen')
    #myGrass=Rectangle(Point(x,y),Point(x+50,y+70))   
    
    myGrass.draw(myHouse)

main()
