#Maria Girgis 
#First try Proj 3 

from graphics import*

myDecoder=GraphWin("My Coder!",600,600)

encoderText=Text(Point(200,200), "Encode")
decoderText=Text(Point(300,200), "Decode")
encoderText.draw(myDecoder)
decoderText.draw(myDecoder)

def encoder():
    userMessageE=input("please enter a message in english to encode to ASCI.")
    #ord(userMessageE)
    for i in range(len(userMessageE)):
        print(userMessageE[i])
        encodedMessageE=ord(userMessageE[i])
        print(encodedMessageE)

encoder()

def decoder():

    userMessageD=eval(input("please enter a message in english to encode to ASCI."))
    #ord(userMessageE)
    for i in range(userMessageD):
        print(userMessageD[i])
        encodedMessageD=chr(userMessageD[i])
        print(encodedMessageD)

decoder()
