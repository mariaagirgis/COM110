#idea for program A

def main():
    n=eval(input("What is the weather in fareinheit?"))
    while n<=30 
        print("You should wear a winter jacket, gloves, a scarf, and a hat")
    if n<=30
        print("You should wear a jacket and long pants")

#Example of For loop 
for i in range(25):
    print("I'm saying this 25 times!")



#Program B Pseudo Code

n=eval(input("How many people are in your group?"))
ask for height the number of times equvalent to n

for i in range(n) ask for heights
    
#How do I make it so the variable name changes everytime the
#computer asks? 

height1=eval(input("Enter height for person 1 in feet and inches, seperated by comma"))

#Do I use a x,y here?
#multiply x value by 12 for the number of inches and add it to value of y
#for total number of inches then add to total sum 


Variable called totalInches
Variable called totalCentimeters

for n 


#Have python add up the height values of each person and divide it by the value
#of "n" that was recieved

#Computation from inch to centimeters is multiply inch value by 2.54


print("the average height in your group in inches is", totalInches/n)
print("the average height in your group in centimeters is", totalCentimeters/n)
