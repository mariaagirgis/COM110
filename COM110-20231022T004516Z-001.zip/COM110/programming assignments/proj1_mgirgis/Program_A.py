#Maria Girgis
#Programming Assignment 1 
#Program A
#9/14/22
#Due date 9/19/22
#The purpose of this program is to play rock paper scissors against the computer 10 times, and the computer will report back your average wins, losses, and ties.

#The import random function at the top tells the computer it will be producing a random value which is used to produce whether the computer plays rock paper or scissors
import random

#main function which holds the for loop that runs the program 
def main():

#three variables are defined before the for loop because there will be values added to these variables in the program      
    win=0
    tie=0
    loss=0
    
    games=eval(input("How many times would you like to play rock paper scissors against the computer?"))
          
    #loop runs the game of rock, paper, scissors 10 times
    for i in range(games):
        #two lines of code asks the user to input rock, paper, or scissors and has the computer generate a random choice of rock, paper, or scissors.
        userMove=input(str("enter either rock,paper,or scissors to play against computer "))
        computerMove=random.choice(("rock","paper","scissors"))
        #if statement says that if the users move is paper, and the computers move is rock, the user wins. 
        if userMove=="paper" and computerMove=="rock":
            print("the computer played rock; you win!")
            win+=1
        # if statement says that if the users move is scissors, and the computers move is paper, the user wins. 
        elif userMove=="scissors" and computerMove=="paper":
            print("the computer played paper; you win!")
            win+=1
        #if statement says that if the users move is rock, and the computers move is scissors, the user wins.
        elif userMove=="rock" and computerMove=="scissors":
            print("the computer played scissors; you win!")
            win+=1
        #if statement says that if the users move is rock and the computers move is paper, the user loses.
        elif userMove=="rock" and computerMove=="paper":
            print("the computer played paper, you lose :(")
            loss+=1
        #if statement says that if the users move is paper and the computers move is scissors, the user loses.
        elif userMove=="paper" and computerMove=="scissors":
            print("the computer played scissors, you lose :(")
            loss+=1
        #if statement says that if the users move is scissors and the computers move is rock, the user loses.
        elif userMove=="scissors" and computerMove=="rock":
            print("the computer played rock, you lose :(")
            loss+=1
        #if statement says that if the computer move is the same as the user move, the user ties with the computer.
        elif userMove==computerMove:
            print("you tied. Play again!")
            tie+=1
            
    #print statements tell the user the amount of times they won, loss, and tied. 
    print("you won",win,"times")
    print("you lost",loss,"times")
    print("you tied",tie,"times")
    
    #if statements calculates the average wins, losses, and ties of the user. These outputs are only printed if the corresponding variable is greater than 0. 
    if loss>0:
        print("your average losses are "+str(round(loss/games*100))+"% of the time")
    if win>0:
        print("your average wins are "+str(round(win/games*100))+"% of the time")
    if tie>0:
        print("your average ties are "+str(round(tie/games*100))+"% of the time")
    
main()


