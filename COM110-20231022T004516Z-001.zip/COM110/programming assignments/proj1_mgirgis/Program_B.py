#Maria Girgis
#Due Date 9/19/22
#Programming Assignment 1
#Program B
#This program finds the average height of a group in feet and centimeters using a users inputted values.

#the main function holds the main functionality of the program.
def main():
    #In these lines I set all my variables equal to zero because values will be added to them when the program runs. 
    finalCentimeters=0
    averageCentimeters=0
    centimeters=0
    averageFeet=0
    averageInches=0

    #These two lines are telling the user what the program will do and asks how many people are in the group they are inputting information in for.
    print("With this program, you can tell the computer how many people you have in your group and their heights in feet and inches, and the computer will tell you their height in feet and inches, centimeters, and the average height of your group in feet and centimeters")
    people=eval(input("How many people are in your group?"))

    #This for loop runs n amont of times. It calculates the average height of the group in centimeters and feet and inches. 
    for i in range(people):
        #input function asks the user for each persons height in feet and inches. 
        feet,inches=eval(input("Enter height for person in feet and inches, seperated by a comma for example: 5,6:"))
        #this line adds up all the centimeters using the feet and inches information given by the user.
        centimeters=round(feet*30.48+inches*2.54)
        #adds the above variable centimeters to the variable finalCentimeters. 
        finalCentimeters=centimeters+finalCentimeters
        #the variable in place to hold the average centimers using the variable finalCentimeters and dividing it by variable people. 
        averageCentimeters=finalCentimeters/people
        #calculates the average feet by taking the variable averageCentimeters and divides it by the conversion from centimeters to feet. 
        averagefeet=averageCentimeters//30.48
        #These find the average inches of the group 
        averageinches=((averageCentimeters/30.48)-(averageCentimeters//30.48))*12
        #print out the height of each person in feet and centimeters after the user gives the computer height information.
        print("Height of person",int(i+1),"in feet and inches is",str(feet)+"'"+str(inches)+'" ')
        print("height of person",int(i+1),"in centimeters is",centimeters)
    #statements that print the average height of the group in feet and centimeters.
    print("the average height of your group in feet and inches is",str(round(averagefeet))+"'"+str(round(averageinches,1))+'"')
    print("the average height of your group in centimeters is",round(averageCentimeters))
        
main()





