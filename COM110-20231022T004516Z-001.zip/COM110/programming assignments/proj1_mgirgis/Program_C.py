#Maria Girgis
#Programming Assignment 1
#Program C Fibonacci Sequence
#9/14/22
#Due Date 9/19/22

#Explains purpose of program to the user and tells them what to do.
print("Hello user, today you are going to learn the Fibonacci Sequence. This is a counting sequence where each value is the result of the two previous values being added up")
print("For example, the first number of the sequence is 0, and the second number of the sequence is 1, so the third number of the sequence would be the result of adding 0 and 1 together. So the third number in the sequence is 1")

#Setting variables equal to zero that will soon change based on the sequence. 
n1=0
n2=1

#asking user which Fibonacci number they want to know. 
n=eval(input("Which Fibonacci number would you like to know?"))

#for loop that does the mathematical computations for the Fibonacci Sequence.  
for i in range(n-2):
    result=n1+n2
    n1=n2
    n2=result
    
#print statement that prints out the users desired number in the Fibonacci Sequence. 
print("the",str(n)+"th"+ " number in the Fibonacci sequence is",result)
    

