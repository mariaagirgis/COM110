#Maria Girgis
#Programming Assignment 2
#Due Date 10/3/22
#The purpose of this program is to do linguistic operation on .txt files. The files being used in this program are the files for the Hunger Games Trilogy. 

#Main function holds the menu of options and explains options for user to choose from.
def main():
    print("Hello reader. There are three books that this program will reference. It will reference The Hunger Games, The Hunger Games:Catching Fire, and the Hunger Games:Mockingjay Part 1.")
    print("You have the option to choose from three word processing functions. These functions will act on the .txt files for the books mentioned above.")
    print("You have three options! You can choose to: \n (A)Count the amount of words in each book and calculate average word length \n (B)Replace the main character's name with your name and write a new .txt file \n (C)Find the amount of times key phrases or words are used in each book.")
    userPick=input("Please type in A, B, or C and hit enter to do these functions to each of the books.")
    #If statements that run functions dependending on user input 
    if userPick=="A":
        wordCounter()
    elif userPick=="B":
        replaceWord()
    elif userPick=="C":
        findPhrase()
        
#function that counts the number of words in each book and calculates rounded average word length for each book.      
def wordCounter():

    #setting variables to zero that will eventually have value added to them 
    number_of_words0=0
    number_of_words1=0
    number_of_words2=0
    Sum=0
    Sum1=0
    Sum2=0

    #opens file for book 1, splits contents     
    inFile0=open('(1) The Hunger Games.txt','r',encoding='utf-8')
    book0WC=inFile0.read()
    book0WCData=book0WC.split()
    number_of_words0+=len(book0WCData)
    #counts the amount of characters in words and calculates average characters in words.
    for ch in book0WCData:
        character=len(ch)
        Sum=Sum+character
    average=(Sum)//number_of_words0
    print("The average word length in The Hunger Games is",average, "characters")
    print("there are", number_of_words0, "number of words in The Hunger Games")

    #opens file for book 2, splits contents   
    inFile1=open('(2) Catching Fire.txt','r',encoding='utf-8')
    book1WC=inFile1.read()
    book1WCData=book1WC.split()
    number_of_words1+=len(book1WCData)
    #counts the amount of characters in words and calculates average characters in words.
    for ch1 in book1WC.split():
        character1=len(ch)
        Sum1=Sum1+character1
    average1=(Sum1)//number_of_words1
    print("the average word length in Catching Fire is",average,"characters")
    print("there are", number_of_words1, "number of words in Catching Fire")

    #opens file for book 3, splits contents   
    inFile2=open('(3.1) Mockingjay.txt','r',encoding='utf-8')
    book2WC=inFile2.read()
    book2WCData=book2WC.split()
    number_of_words2+=len(book2WCData)
    #counts the amount of characters in words and calculates average characters in words.
    for ch2 in book2WC.split():
        character2=len(ch)
        Sum2=Sum2+character2
    average2=(Sum1)//number_of_words2
    print("the average word length in Mockingjay is",average2,"characters")
    print("there are",number_of_words2, "number of words in Mockingjay")

    #closing .txt files
    inFile0.close()
    inFile1.close()
    inFile2.close()

#function that replaces main character's name with given input and writes a new .txt file
def replaceWord():
    #asking user for the name/ word they would like to use to replace main character's name
    nameInput0=str(input("input a name to replace the main character's name and produce a new .txt file for The Hunger Games"))
    book0=open('(1) The Hunger Games.txt','r',encoding='utf-8')
    book0Contents=book0.read()
    #replaces main character's name based on user input 
    replaceName0=book0Contents.replace('Katniss',nameInput0)
    newBook0=open('userBook.txt','w',encoding='utf-8')
    newBook0.write(replaceName0)
    userChoice0=input("would you like to print out your new book? Please type yes or no.")
    #prints new .txt file is user wishes 
    if userChoice0=='yes':
        print(replaceName0)
    #closes book file
    newBook0.close()
    book0.close()

    #asking user for the name/ word they would like to use to replace main character's name
    nameInput1=str(input("input a name to replace the main character's name and produce a new .txt file for Catching Fire"))
    book1=open('(2) Catching Fire.txt','r',encoding='utf-8')
    book1Contents=book1.read()
    #replaces main character's name based on user input 
    replaceName1=book1Contents.replace('Katniss',nameInput1)
    newBook1=open('userBook1.txt','w',encoding='utf-8')
    newBook1.write(replaceName1)
    userChoice1=input("would you like to print out your new book? Please type yes or no.")
    #prints new .txt file is user wishes 
    if userChoice1=='yes':
        print(replaceName1)
    #closes book file
    newBook1.close()
    book1.close()

    #asking user for the name/ word they would like to use to replace main character's name
    nameInput2=str(input("input a name to replace the main character's name and produce a new .txt file for Mockingjay"))
    book2=open('(3.1) Mockingjay.txt','r',encoding='utf-8')
    book2Contents=book2.read()
    #replaces main character's name based on user input 
    replaceName2=book2Contents.replace('Katniss',nameInput2)
    newBook2=open('userBook2.txt','w',encoding='utf-8')
    newBook2.write(replaceName2)
    userChoice2=input("would you like to print out your new book? Please type yes or no.")
    #prints new .txt file is user wishes 
    if userChoice2=='yes':
        print(replaceName2)
    #closes book file 
    newBook2.close()
    book2.close()

#function that finds notorious phrases in each book 
def findPhrase():
    #initiating variable as zero 
    happyGames=0
    #opens, reads, and counts the amount of times the book references Hunger Games
    hGames1=open('(1) The Hunger Games.txt','r',encoding='utf-8')
    hGames1Contents=hGames1.read()
    numHappyGames=hGames1Contents.count("Hunger Games")
    happyGames=happyGames+numHappyGames
    print('This book says Happy Hunger Games!',happyGames,"times")
    
    #intiating variable as zero
    Peeta=0
    #opens, reads, and counts the amount of times the book references character Peeta.
    hGames2=open('(2) Catching Fire.txt','r',encoding='utf-8')
    hGames2Contents=hGames2.read()
    numPeeta=hGames2Contents.count("Peeta")
    Peeta=Peeta+numPeeta
    print("This book references Katiniss and Peeta's realtionship a lot. Catching Fire says Peeta's name", Peeta,"times")

    #initiating variable as zero 
    Capitol=0
    #opens, reads, and counts the amount of times the book references the Capitol
    hGames3=open('(3.1) Mockingjay.txt','r',encoding='utf-8')
    hGames3Contents=hGames3.read()
    numCapitol=hGames3Contents.count("Capitol")
    Capitol=Capitol+numCapitol
    print("This book is about a rebellion against the Capitol. Mockingjay references the capitol", Capitol, "times")

    #closes all three book files. 
    hGames1.close()
    hGames2.close()
    hGames3.close()
    
main()

