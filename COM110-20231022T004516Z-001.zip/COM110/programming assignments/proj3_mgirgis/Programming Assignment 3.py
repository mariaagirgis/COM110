#Maria Girgis 
#Programming Assignment 3
#Due date 10/26/22
#This program reads a string or text file given by user and encodes/decodes it

from graphics import*
#imported module for animated title screen
from TitleScreen import*
        
def main():
    
    #Creating window
    myCoder=GraphWin("My Coder!",600,600)
    #setting background color, creating text points for entry objects
    myCoder.setBackground(color_rgb(204,255,255))
    stringText=Text(Point(150,100), "String/File name")
    keyText=Text(Point(150,200), "Key Value")
    #importing image to window
    pyramidsSketch=Image(Point(450,500), "PYRAMIDS.gif")
    pyramidsSketch.draw(myCoder)
    #making entry objects for user to input string/file name and key value 
    entry = Entry(Point(300, 100), 20)
    entry.draw(myCoder)
    entry2 = Entry(Point(300, 200), 20)
    entry2.draw(myCoder)
    stringText.draw(myCoder)
    keyText.draw(myCoder)
    #Point created to be referenced in drawButton function
    point1=Point(100,300)
    point2=Point(165,375)
    point3=Point(100,400)
    point4=Point(165,475)
    point5=Point(100,500)
    point6=Point(165,550)
    point7=Point(165,500)
    point8=Point(230,550)
    point9=Point(160,300)
    point10=Point(225,375)
    point11=Point(165,400)
    point12=Point(230,475)
    #Drawing buttons
    encodeButton=drawButton(myCoder,point1,point2, "Encode!")
    decodeButton=drawButton(myCoder,point3,point4,"Decode!")
    goAgain=drawButton(myCoder,point5,point6, "Code again!")
    quitBtn=drawButton(myCoder,point7,point8, "Quit..")
    encodeFile=drawButton(myCoder,point9,point10, "Encode File!")
    decodeFile=drawButton(myCoder,point11,point12, "Decode File!")
   
    #Looks for user mouse click 
    pt = myCoder.getMouse()
    #gets text from entry points
    userKey=entry2.getText()
    userString=entry.getText()
  
    #if encode button is clicked, runs encode function with user given values
    if isClicked(encodeButton, pt)==True:
        encodedMessage=encoder(userString,userKey)
        #draws results onto window 
        displayResultE=Text(Point(275,250),encodedMessage)
        displayResultE.setFace("helvetica")
        displayResultE.setSize(22)
        displayResultE.setStyle("bold italic")
        displayResultE.setTextColor(color_rgb(254,201,212))
        displayResultE.draw(myCoder)
    
    #if decode button is clicked, runs decode function with user given values    
    elif isClicked(decodeButton, pt)==True:
        decodedMessage=decoder(userString, userKey)
        #draws results onto window
        displayResultD=Text(Point(275,250), decodedMessage)
        displayResultD.setFace("helvetica")
        displayResultD.setSize(22)
        displayResultD.setStyle("bold italic")
        displayResultD.setTextColor(color_rgb(254,201,212))
        displayResultD.draw(myCoder)

    #if encode file button is clicked, runs encode function with user given txt. file
    elif isClicked(encodeFile, pt) ==True:
        inFile=open(userString,"r", encoding= "utf8")
        fileText=inFile.read()
        encodedFile=encoder(fileText,userKey)
        #writes a new file for encoded .txt file 
        newFile=open('newfileE.txt','w', encoding='utf-8')
        displayResultEF=Text(Point(275,250), 'Your new file has been written')
        displayResultEF.setFace("helvetica")
        displayResultEF.setSize(18)
        displayResultEF.setStyle("bold italic")
        displayResultEF.setTextColor(color_rgb(254,201,212))
        displayResultEF.draw(myCoder)
        
    #if decode file button is clicked, runs decode function with user given txt. file    
    elif isClicked(decodeFile, pt) ==True:
        inFile1=open(userString, 'r', encoding='utf8')
        displayResultDF=inFile1.read()
        decodedFile=decoder(fileTest, userKey)
        #writes a new file for decoded .txt file 
        newFile1=open('newfileD.txt','w',encoding='utf-8')
        newFile1.write(decodedFile)
        prin(newFile1)
        displayResultDF=Text(Point(275,250), 'Your new file has been written')
        displayResultDF.setFace("helvetica")
        displayResultDF.setSize(18)
        displayResultDF.setStyle("bold italic")
        displayResultDF.setTextColor(color_rgb(254,201,212))
        displayResultDF.draw(myCoder)
    
    #Looks for user mouse click again to either code again or exit the program
    pt2= myCoder.getMouse()
    #myCoder.close()
    if isClicked(goAgain, pt2)== True:
        myCoder.close()
        main()
    elif isClicked(quitBtn,pt2)== True:
        myCoder.close()

#drawButton function from Professor Lee's drawButton.py
def drawButton(win, pt1, pt2, label):
    button = Rectangle(pt1, pt2)
    button.setFill(color_rgb(254,201,212))
    button.draw(win)
    centerX = (pt1.getX() + pt2.getX()) / 2.0
    centerY = (pt1.getY() + pt2.getY()) / 2.0
    center=Point(centerX,centerY)
    myLabel=Text(center,label)
    myLabel=myLabel.draw(win)

    return button

#isClicked function to tell if user click lands in parameters of button
#from Professor Lee's drawButton.py
def isClicked(button,point):
    x=point.getX()
    y=point.getY()
    pt1=button.getP1()
    print(pt1)
    pt2=button.getP2()
    print(pt2)
    if(pt1.getX() < x < pt2.getX() and pt1.getY() < y < pt2.getY()):
        return True
        print("clicked")
    else:
        return False 

#encoder function with parameters for key value and string/file name  
def encoder (string,key) :
    codedMessage=""
    key = int(key)
    for character in string:
        if character. isalpha() == False: #checks to see if it is a letter
            codedMessage += character
        else: #checks to see if shift exceeds the alphabet so it can shift
            if (ord(character) +key > 90 and character== character.upper()) or (ord(character)+key > 122 and character == character.lower()):
                codedMessage+=chr(ord(character) +key-26) #moves to start of alphabet
            else:
                codedMessage+=chr(ord(character) +key)
    return ("Your encoded message is:"+ codedMessage)

#decoder function with parameters for key value and string/file name
def decoder (string,key):
    codedMessage=""
    key= int(key)
    for character in string:
        if character.isalpha()==False: #checks to see if it is a letter
            codedMessage += character
        else: #checks to see if shift exceeds the alphabet so it can shift
            if ((ord(character)-key < 65) and (character == character.upper())) or ((ord(character)-key < 97) and (character== character.lower())):
                codedMessage += chr(ord(character)-key+26) #moves it to end of alphabet
            else:
                codedMessage += chr(ord (character)-key)
                
    return ("Your decoded message is:"+ codedMessage)


#myCoder.close()
    
main()

