#Maria Girgis 
#First try Proj 3 

from graphics import*
#from drawButton import*



def main():
        
    myCoder=GraphWin("My Coder!",600,600)
    stringText=Text(Point(150,100), "String")
    keyText=Text(Point(150,200), "Key Value")
    entry = Entry(Point(300, 100), 20)
    entry.draw(myCoder)
    entry2 = Entry(Point(300, 200), 20)
    entry2.draw(myCoder)
    stringText.draw(myCoder)
    keyText.draw(myCoder)
    point1=Point(400,100)
    point2=Point(450,200)
    point3=Point(200,400)
    point4=Point(250,500)
    point5=Point(100,400)
    point6=Point(200,450)
    point7=Point(300,400)
    point8=Point(350,450)
    encodeButton=drawButton(myCoder,point1,point2, "encode")
    decodeButton=drawButton(myCoder,point3,point4,"decode")
    goAgain=drawButton(myCoder,point5,point6, "Code again")
    quitBtn=drawButton(myCoder,point7,point8, "Quit")
    
       #from professor lee's drawButton.py
    
    #textBox=entry.getText()
    pt = myCoder.getMouse()
    userKey=entry2.getText()
    userString=entry.getText()
    
    #print(pt)
    

    if isClicked(encodeButton, pt)==True:
        print("clicked")
        encodedMessage=encoder(userString,userKey)
        print(encodedMessage)
        displayResultE=Text(Point(150,350), encodedMessage)
        displayResultE.draw(myCoder)
        
    elif isClicked(decodeButton, pt)==True:
        decodedMessage=decoder(userString, userKey)
        displayResultD=Text(Point(150,350), decodedMessage) 
        displayResultD.draw(myCoder)
        
    pt2= myCoder.getMouse()
    #myCoder.close()
    if isClicked(goAgain, pt2)== True:
        myCoder.close()
        main()
    elif isClicked(quitBtn,pt2)== True:
        myCoder.close()
        


def drawButton(win, pt1, pt2, label):
    button = Rectangle(pt1, pt2)
    button.setFill("yellow")
    button.draw(win)
    centerX = (pt1.getX() + pt2.getX()) / 2.0
    centerY = (pt1.getY() + pt2.getY()) / 2.0
    center=Point(centerX,centerY)
    myLabel=Text(center,label)
    myLabel=myLabel.draw(win)

    return button 

def isClicked(button,point): 
#we are going to implement this soon!
    x=point.getX()
    y=point.getY()
    pt1=button.getP1()
    print(pt1)
    pt2=button.getP2()
    print(pt2)
    if(pt1.getX() < x < pt2.getX() and pt1.getY() < y < pt2.getY()):
        return True
        print("clicked")
    else:
        return False 


def encoder(string,key):

    encodedMessage=""
    #ord(userMessageE)
    for i in range(len(string)):
        #print(userMessageE[i])
        key = int(key)
        encodedNumber=ord(string[i])+key
        encodedCharacter=chr(encodedNumber)
        encodedMessage+= encodedCharacter
    print(encodedMessage)
        
    
    return encodedMessage

#encoder()

def decoder(string,key):

    decodedMessage=""
    string.upper()              
    #ord(userMessageE)
    for i in range(len(string)):
        #print(userMessageE[i])
        key = int(key)
        decodedNumber=ord(string[i])-key
        decodedCharacter=chr(decodedNumber)
        decodedMessage+=decodedCharacter
        
    print(decodedMessage)
       
    
    return decodedMessage


#myCoder.close()
    
main()

