#Maria Girgis Start Screen for Ceaser Cypher 
#Animated start screen, intro, and start button 

from graphics import *
#from professor Lee's drawButton.py
def drawButton(win, pt1, pt2, label):
    button = Rectangle(pt1, pt2)
    button.setFill("lightblue")
    button.draw(win)

    centerX = (pt1.getX() + pt2.getX()) / 2.0
    centerY = (pt1.getY() + pt2.getY()) / 2.0
    center = Point(centerX,centerY)
    myLabel = Text(center,label)
    myLabel = myLabel.draw(win)
    
    return button

def isClicked(button, point):
    x = point.getX()
    y = point.getY()
    pt1 = button.getP1()
    pt2 = button.getP2()

    if (pt1.getX()<x<pt2.getX() and pt1.getY()<y<pt2.getY()):
        #print("clicked")
        return True

def main():

    #create window
    myWin = GraphWin("Start Screen", 600, 600)
    #changes background color 
    myWin.setBackground(color_rgb(254,201,212))
    #draws arrow seen on intro screen
    aLine=Line(Point(26,215),Point(86,184))
    bLine=Line(Point(86,184),Point(112,186))
    cLine=Line(Point(118,193),Point(112,213))
    dLine=Line(Point(112,213),Point(48,248))
    eLine=Line(Point(48,248),Point(48,223))
    fLine=Line(Point(48,223),Point(24,216))
    gLine=Line(Point(118,193),Point(113,186))
    hLine=Line(Point(113,186),Point(275,93))
    iLine=Line(Point(118,193),Point(278,100))
    jLine=Line(Point(281,104),Point(272,88))
    kLine=Line(Point(281,104),Point(300,87))
    lLine=Line(Point(272,88),Point(291,78))
    mLine=Line(Point(299,78),Point(301,105))
    nLine=Line(Point(299,78),Point(276,72))
    oLine=Line(Point(276,72),Point(343,44))
    pLine=Line(Point(343,44),Point(301,105))
    qLine=Line(Point(299,78),Point(343,44))
    aLine.setWidth(3)
    bLine.setWidth(3)
    cLine.setWidth(3)
    dLine.setWidth(3)
    eLine.setWidth(3)
    fLine.setWidth(3)
    gLine.setWidth(3)
    hLine.setWidth(3)
    iLine.setWidth(3)
    jLine.setWidth(3)
    kLine.setWidth(3)
    lLine.setWidth(3)
    mLine.setWidth(3)
    nLine.setWidth(3)
    oLine.setWidth(3)
    pLine.setWidth(3)
    qLine.setWidth(3)
    
    aLine.draw(myWin)
    bLine.draw(myWin)
    cLine.draw(myWin)
    dLine.draw(myWin)
    eLine.draw(myWin)
    fLine.draw(myWin)
    gLine.draw(myWin)
    hLine.draw(myWin)
    iLine.draw(myWin)
    jLine.draw(myWin)
    kLine.draw(myWin)
    lLine.draw(myWin)
    mLine.draw(myWin)
    nLine.draw(myWin)
    oLine.draw(myWin)
    pLine.draw(myWin)
    qLine.draw(myWin)
    point1 = Point(250,450)
    point2 = Point(350,500)
    #imports image 
    arrowImage=Image(Point(100,400), "ARROW-SS.gif")
    arrowImage.draw(myWin)
    #moves image
    for i in range(75):
        arrowImage.move(10,-10)
    #sets style
    describeFunctionality=Text(Point(450,100),"This is Maria's Coder!\n This program encodes/decodes any file\n or string that you would like!\n Simply enter a string/file name and a key value\n and click the corresponding button!")
    describeFunctionality.draw(myWin)
    introMessage=Text(Point(300,400), "Welcome to Maria's Coder! \nClick the start button to begin coding/encoding!")
    introMessage.setFace("helvetica")
    introMessage.setSize(22)
    introMessage.setStyle("bold italic")
    introMessage.setTextColor("white")
    introMessage.draw(myWin)                      
    startBtn = drawButton(myWin,point1,point2, "Start")
    #looks for user click to start program
    pt = myWin.getMouse()

    if (isClicked(startBtn, pt)):
        myWin.close()


main()
