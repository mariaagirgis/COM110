#MAria Girgis
#PA 4 midpoint check

from random import randrange
from graphics import*

def main():
    wordList=["watermelon","strawberry","peach","pineapple","koala","fig","coconut","nut","foot","leg","knee"]

    myCloud=GraphWin("My Cloud", 600,600)
    myCloud.setBackground(color_rgb(254,201,212))
    
    #generates basic level word cloud with list of words 
    for i in range (len(wordList)):
        randWord=Text(Point(randrange(1,600),randrange(1,600)), wordList[i])
        randWord.setSize(randrange(5,36))
        r=randrange(1,255)
        g=randrange(1,255)
        b=randrange(1,255)
        randWord.setFill(color_rgb(r,g,b))
        randWord.draw(myCloud)
    
main()


def byFreq(pair):
    return pair[1]

def run():
    print ("This program analyzes word frequency in a file")
    print ("and prints a report on the n most frequent words. \n")
    # get the sequence of words from the file
    fname = input ("File to analyze:")
    text = open (fname, 'r').read()
    text = text.lower()
    for ch in '!#$％＆()*+っ-./::<=>?00117~13-2':
        text = text.replace (ch, ' ')
    words = text.split()
    # construct a dictionary of word counts
    counts = {}
    for w in words:
        counts[w] = counts.get(w,0) + 1
    # output analysis of n most frequent words.
    n = eval(input("Output analysis of how many words?"))
    items = list(counts.items())
    items.sort()
    items.sort(key=byFreq,reverse=True)
    for i in range(n):
        word,count = items[i]
        print("{0: <15}{1:>5}".format(word, count))
        
if __name__ == '__main__': run()


