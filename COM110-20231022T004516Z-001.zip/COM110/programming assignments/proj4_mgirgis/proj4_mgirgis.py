#Maria Girgis
#Programming Assignment 4
#Due Date:11/9/22
#This program makes a word bubble using words from a user inputted .txt file

#Importing graphics.py, and random
from graphics import*
from random import randrange
import random
import math
import string

#Function to sort words by frequency 
def byFreq(pair):
    return pair[1]
#detects stop words and prevents them from getting added to 
def sortFreq(fname):
    #opens .txt file of stop words and reads it, makes it lower case, and splits it.
    text = open (fname, 'r').read()
    text = text.lower()
    #removes punctuation from words 
    for ch in '!#$％＆()*+っ-./::<=>?00117~13-2,.':
        text=text.replace(ch,' ')
    words = text.split()
    file=open('stopWords.txt','r',encoding='utf8')
    stopWords=file.read()
    finalWords=[]
    #adds words that are left over after removing stop words to finalWords list
    for ch in words:
        if ch not in stopWords:
            finalWords.append(ch)
    #construct a dictionary of word counts
    counts = {}
    for w in finalWords:
        counts[w] = counts.get(w,0) + 1
    items = list(counts.items())
    items.sort(key=byFreq,reverse=True)
    dictionary=dict(items)
    myList=list(dictionary.keys())
    for i in range(25):
        word,count = items[i]
    counter = 0

    return myList

#function imported from Professor Lee's drawButton.py to constuct "generate cloud" button
def drawButton(win, pt1, pt2, label):
    button = Rectangle(pt1, pt2)
    button.setFill(color_rgb(254,201,212))
    button.draw(win)
    centerX = (pt1.getX() + pt2.getX()) / 2.0
    centerY = (pt1.getY() + pt2.getY()) / 2.0
    center=Point(centerX,centerY)
    myLabel=Text(center,label)
    myLabel=myLabel.draw(win)

    return button

#function imported from Professor Lee's drawButton.py to detect if button is clicked
def isClicked(button,point):
    x=point.getX()
    y=point.getY()
    pt1=button.getP1()
    pt2=button.getP2()
    if(pt1.getX() < x < pt2.getX() and pt1.getY() < y < pt2.getY()):
        return True
        print("clicked")
    else:
        return False
    
#main function
def main():
    #creating window, setting background color, display intro 
    myWin=GraphWin("Maria's Word Cloud",600,600)
    myWin.setBackground(color_rgb(254,201,212))
    askUser=Text(Point(160,30),"Welcome to Maria's Word Clouds! \n Input a .txt file to be analyzed or use the default \n one to  create a word Bubble!")
    askUser.setSize(15)
    askUser.draw(myWin)
    #entry point for user to enter .txt file name 
    takeFile=Entry(Point(400,35),20)
    takeFile.setText("The Hunger Games.txt")
    takeFile.draw(myWin)
    point1=Point(500,10)
    point2=Point(585,65)
    #button to be clicked after .txt file is typed in 
    generateBtn=drawButton(myWin,point1,point2, "generate cloud")
    #looks for user's moust click
    click1=myWin.getMouse()

    #constructs point list for random and non overlapping word layout 
    pointList=[]
    for x in range(80,600,50):
        for y in range(80,600,50):
            point = Point(x,y)
            pointList.append(point)
        random.shuffle(pointList)

    #if generate cloud button is clicked, generates word cloud 
    if isClicked(generateBtn,click1):
        fileName=takeFile.getText()
        #sorts frequency of words from .txt file
        wordList=sortFreq(fileName)
        #makes 12 words in word cloud 
        for i in range(12):
            pt=pointList[i]
            words=Text(pt,wordList[i])
            words.setSize(50-i*2)
            r=randrange(1,255)
            g=randrange(1,255)
            b=randrange(1,255)
            #randomly selects color 
            words.setFill(color_rgb(r,g,b))
            words.draw(myWin)
main()

