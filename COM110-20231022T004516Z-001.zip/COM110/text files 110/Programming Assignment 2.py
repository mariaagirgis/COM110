#Maria Girgis
#Programming assignment 2

#how many similies?
#ask user if they would like to know the number of??
#may the odds be ever in your favor
#list all notable lines in hunger games
#have user type in three digit number and see what string corresponds to it just like in the decoder program iin lecture 5 



def wordCounter():
    
    number_of_words0=0
    number_of_words1=0
    number_of_words2=0
    
    
    #data_file0=open('(1) The Hunger Games.txt','r',encoding='utf-8')
##    with open('(1) The Hunger Games.txt','r',encoding='utf-8') as data_file0:
##        for line0 in data_file0:
##            data0=line0.split()
        #print(data)
            #number_of_words0+= len(data0)
    
    #print(number_of_words0)

    
    inFile0=open('(1) The Hunger Games.txt','r',encoding='utf-8')
    book1WC=










    
    #data_file1=open('(2) Catching Fire.txt','r',encoding='utf-8')

    with open('(2) Catching Fire.txt','r',encoding='utf-8') as data_file1:
        for line1 in data_file1:
            data1=line1.split()
    #print(data)

            number_of_words1+= len(data1)
    
    print(number_of_words1)


    #data_file2=open('(3.1) Mockingjay.txt','r',encoding='utf-8')

    with open('(3.1) Mockingjay.txt','r',encoding='utf-8') as data_file2:
        for line2 in data_file2:
            data2=line2.split()
    #print(data)
            number_of_words2+= len(data2)
    
    print(number_of_words2)

#wordCounter()

def replaceWord():
    nameInput=str(input("input a name to replace the main character's name and produce a new .txt file"))
    book1=open('(1) The Hunger Games.txt','r',encoding='utf-8')
    book1Contents=book1.read()
    replaceName=book1Contents.replace('Katniss',nameInput)
    newBook=open('userBook.txt','w',encoding='utf-8')
    newBook.write(replaceName)
    userChoice=input("would you like to print out your new book? Please type yes or no.")
    if userChoice=='yes':
        print(replaceName)
    newBook.close()
    book1.close()

#replaceWord()

def findPhrase():
    happyGames=0
    hGames1=open('(1) The Hunger Games.txt','r',encoding='utf-8')
    hGames1Contents=hGames1.read()
    numHappyGames=hGames1Contents.count("Hunger Games")
    happyGames=happyGames+numHappyGames
    print('This book says Happy Hunger Games!',happyGames,"times")
                 
findPhrase()
    
    
    
#fileOpen=fileOpen.split()

#print(fileOpen)



#inFile0=open('(1) The Hunger Games.txt','r',encoding='utf-8')

#allLines0=inFile0.readlines()
#print(allLines0)

#numLines0=len(allLines0)
#print('The Hunger Games.txt has total', numLines0,"lines.")
#inFile0.close()


#inFile1=open('(2) Catching Fire.txt','r',encoding='utf-8')

#allLines1=inFile1.readlines()
#print(allLines1)

#numLines1=len(allLines1)
#print('Catching Fire.txt has total', numLines1,"lines.")
#inFile1.close()

#inFile2=open('(3.1) Mockingjay.txt','r',encoding='utf-8')

#allLines2=inFile2.readlines()
#print(allLines2)

#numLines2=len(allLines2)
#print('(2.1) Mockingjay.txt has total', numLines2,"lines.")
#inFile2.close()

#I volunteer! I gasp. I volunteer as tribute!
