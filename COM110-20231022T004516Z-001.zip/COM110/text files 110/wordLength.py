#COM110: wordLength.py
#The program compute the average length of the sentences

def main():

    #open file
    inFile = open('theprogrammer.txt', 'r', encoding='utf-8')

    #read all contents from the file
    allContents = inFile.read()

    #split the contents into sentences: assume a period is good candidate
    #to split sentences
    ### your code here

    numSentence=allContents.count('.')


    
    #split the contents into words
    ### your code here
    wordList=numSentence.split()
    
    #avg length of sentence: total number of words / total number of sentence
    ### your code here
    avgLength=len(wordList)/numSentence

    #also can computer average length of words
    ### your code here
    print("the average length of sentences", avgLength)
    #close file
    inFile.close()
        
main()
