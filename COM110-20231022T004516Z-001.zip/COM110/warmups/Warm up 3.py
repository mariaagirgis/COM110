#Maria Girgis
#Warm Up 3
#Due 9/21/22


scores=0
sumOfScores=0


#I started off with this input function to ask the user how many test grades they needed averaged. I set a variable that made sense to the programs that I knew I would call later.
grades=eval(input("How many test grades would you like to average?"))

#This loop runs the amount of times corresponding to how many test grades the user needs averaged. This was possible by setting the parameter of the for loop as the variable grades. 
for i in range(grades):
#This input function asks the user for the test grades. I struggled to get the computer to say the number of each test grade. I then struggled to add the colon after the number given.
#I figured out how to do these things by refrencing my Program B from Programming Assignment 1 
    scores=int(input("Please enter test grade "+str(i+1)+":"))
#This finalScore variable was created to add up all the scores the computer recieved, which later helped me find the average. 
    sumOfScores=scores+sumOfScores

#I printed the average test grades. 
print("your test average is",sumOfScores/grades)

#The code runs the way it is supposed to. I checked it by doing the calculations on my own calculator to make sure they were accurate.
#I had some trouble doing specific things in this code like formatting it according to the instructions on Moodle, but I eventually figured it out.

