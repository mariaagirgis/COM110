#Maria Girgis
#9/22/22
#This program counts the amount of words in a .txt file

#opens and reads text file
testFile=open('test.txt','r', encoding ='utf8')

#splits file contents 
totalWords=testFile.split()

#prints number of words 
print('test.txt has total', len(totalWords),"words")

#closes file
testFile.close()

#This warmup was helpful for our second programming assignment. It was managable
#do because I had already done it for the midpoint check.
#I first opened test.txt and had the computer read it
#I then split the words in test.txt to they can then be counted using len 



