#Maria Girgis
#9/22/22
#Program creates a user id and emmail for a connecticut college student

wholeName=str(input("Please type in your whole name with spaces in between"))

#making name lower case to be suitable for the user id and splitting name
nList=wholeName.lower().split()

#assigning first, middle, and last name to variables
fName, mName, lName= nList[0], nList[1], nList[2]

#Function to make user name 
def userid():
    userId=fName[0]+mName[0]+lName[:3]
    print("your user id is", userId)

def email():
    email=fName+'.'+lName+'@conncoll.edu'
    print('your email is ',email)

userid()
email()

    
#I had some trouble putting the names into a list to split them, but other than that it was a doable program. I made the whole
#user input lower case to suit the user id and split it so that they can be items refrenced from a list.
#I had two functions that are called at the end of the program
