#Maria Girgis
#Warmup 11
#rand functions
from random import randrange

##1. a) 
for i in range(50): 
    randomNumber=randrange(1,53)
    randomerNumber=randrange(-41,80)
    print(randomNumber)
    print(randomerNumber)


