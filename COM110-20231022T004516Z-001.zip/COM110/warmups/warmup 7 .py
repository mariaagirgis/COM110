#Maria Girgis
#This program is an animation using for loop and move functi

from graphics import *
from time import *
 
def main():
    
     #creates window
    win=GraphWin("Fun!", 400,600)
    #rectangle creation from top left corner and bottom right 
    square=Rectangle(Point(100,100),Point(300,300))
    #color rectangle 
    square.setFill("blue")
    #draw into window 
    square.draw(win)
    #creates text on square at point 200,200 

    textMove= Text(Point(200,200), "This is a red square. \n Click to see it move.")
    #draw text on window 
    textMove.draw(win)
    #waiting for mouse click from user 
    win.getMouse()
   #moves square along x 
    for i in range(310):
        square.move(1,0)
        #moves text 
        textMove.move(1,0)
        sleep(0.02)

    #when clicked window closes 
    sendoff = Text(Point(200,400),"Click anywhere to close.")
    sendoff.draw(win)
    win.getMouse()

    win.close()

main()


#To make the text move with the square, I would also add a .move() function to my text drawing function
#i would move the text at the same interval as the square. 
#It took trial and error to get my text to be in the place it needed to be for this warm up
#after some tries I got it wheer I needed it.
#i fullfilled the goal of this warmup by adding onto the original code, not much addition needed.
#Warmup helped me brush up on my graphics skill and made me refrence the house lab that we did
