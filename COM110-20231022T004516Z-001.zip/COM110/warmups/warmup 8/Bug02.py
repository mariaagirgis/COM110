#Maria Girgis
#Bug02.py
#the purpose of this module is to take five mouse clicks from a user
#at each mouse click, program shows coordinate of the click point
#however, while writing the program many errors were encounted
#plesae fix those errors and explain!
#remeber that you need to copy graphics.py file in the same directory
#as this module to run the program

from graphics import *


def drawCoord(win,pt):

    #first draw the click point
    pt.draw(win)

    #create string to show coordinate information: i.e. (x, y)
    #added paranthesis
    xCoord = int( pt.getX())
    yCoord = int(pt.getY())
    text = "(" + str(xCoord) + ", " + str(yCoord) + ")"

    drawCoord(myWin, click)
    #take five clicks
    for i in range(5):
        #wait for a click
        click = myWin.getMouse()
        coordInfo=Text(Point(click,click),click)
        coordInfo.draw(myWin)

def main():

    #create a window
    myWin = GraphWin("Print Coordinate", 400, 400);

    #print out program intro message
    
    introMsg=Text(Point(200, 40),"This program shows the coordinate for your mouse click point\nPlease click anywhere five times.")
    #moved the draw function to a seperate line and set it equal to variable
    introMsg.draw(myWin)
    #changed to myWin
    drawCoord(myWin)
    print(click)
    #wait for one more click to close the window
    myWin.getMouse()
    myWin.close()



main()
#I had to change things like syntactical errors and calling the correct variables in the corrrect spot
#I moved the for loop to the draw function so that the variables refrenced in the function would work as expected
#deleted some unecesary lines 
#This program has a lot of things in common with the house lab that we did in class
#Though this helped, I found myself still struggling to get it working correctly
